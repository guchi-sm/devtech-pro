const mongoose = require('mongoose')

const messageSchema = new mongoose.Schema({
  name:    { type: String, required: true, trim: true },
  email:   { type: String, required: true, trim: true, lowercase: true },
  subject: { type: String, trim: true, default: '' },
  message: { type: String, required: true, trim: true },
  read:    { type: Boolean, default: false },
  readAt:  { type: Date },
}, { timestamps: true })

module.exports = mongoose.model('Message', messageSchema)
